str = 'Hello, IoT'
print(f'A: {str*3}')
print(f'B: {str[:4]}')
print(f'C: {str[6:11]}')
print(f'D: {str.lower()}')
print(f'E: {str[::-1]}')