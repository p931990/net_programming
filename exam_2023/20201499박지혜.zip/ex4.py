from socket import *

sock = socket(AF_INET, SOCK_STREAM)
sock.bind(()'220.69.189.125', 443))
sock.listen(10)

while True:
    c, addr = s.accept()
    sock.send(b'GET / HTTP/1.1\r\n\r\n')
    data = sock.recv(10000)
    msg = data.decode()
    #reg = msg.split()

    #print(reg)
    print(msg)
    sock.close()